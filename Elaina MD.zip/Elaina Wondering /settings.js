const chalk = require("chalk")
const fs = require("fs")
//aumto presence update
global.autoTyping = false // auto tying in gc (true to on, false to off)
global.autoRecord = false // auto recording (true to on, false to off)
global.autoblockmorroco = false // auto block 212 (true to on, false to off)
global.wlcm = false
global.autokickmorroco = false // auto kick 212 (true to on, false to off) 
global.antispam = false //auto kick spammer (true to on, false to off)
global.autosahur = true // auto sahur (true to on, false to off)

//===============SETTING MENU==================\\
global.channel = '120363321465895041@newsletter' // GANTI DENGAN ID CHMU KALO ADA
global.channeln = 'Elaina - Update Info' // GANTI DENGAN NAMA CH MU
//===============SETTING MENU==================\\
global.prefix = ['','!','.','#','&']
global.thumbnail = 'https://raw.githubusercontent.com/belluptaka/dat3/main/uploads/bb3ff5-1771233100633.jpg'
global.music = 'https://raw.githubusercontent.com/belluptaka/dat3/main/uploads/f44e89-1771232509104.mp3'
global.ig = '@itsmeyp'
global.yt = 'Shyocode'
global.ttowner = '@itsmeshyo'
global.ownername = 'ShyoCode'
global.owner = ['62821766429uo','6283121128238'] // SETTING JUGA DI FOLDER DATABASE 
global.ownernomer = '6282176642989'
global.socialm = 'GitHub: -'
global.location = 'Indonesia' 
//========================Setting API=====================\\
global.nz = [
    'nz-e98e71fd41',
    'nz-f0ccb09fe1',
    'nz-d7f75016a2',
    'nz-97bf45bd87',
    'nz-4ce5fb3be3'
    ]
global.frch = [
    "29015f61cbaa2b36f26bcd61c0b087c0421e4f8f16c67809d4b67091863bf483",
    "3b00b2f1d5201dee96ed46eca909ef4be8abdbad1bc876fe6384bc42256ed24f"
    ] // Kalo mau nambah api sendiri ke https://asitha.top/login?ref=ahmadakb6455
//========================setting Payment=====================\\
global.nodana = '082176642988' // KOSONG KAN JIKA TIDAK ADA
global.nogopay = '_' // KOSONG KAN JIKA TIDAK ADA 
global.noovo = false // KOSONG KAN JIKA TIDAK ADA
//==================setting Payment Name===========================\\
global.andana = 'A / W' // KOSONG KAN JIKA TIDAK ADA
global.angopay = '_' // KOSONG KAN JIKA TIDAK ADA
global.anovo = false // KOSONG KAN JIKA TIDAK ADA
//==================setting bot===========================\\
global.botname = "Elaina Asistent💫"
global.ownernumber = '6285187063723'
global.botnumber = '6283867608750'
global.ownername = 'ShyoCode'
global.ownerNumber = ["6282176642989@s.whatsapp.net"]
global.ownerweb = ""
global.websitex = ""
global.wagc = "https://chat.whatsapp.com/LvmL37IubFNCPGU0cp62hA?mode=gi_t"
global.saluran = "https://whatsapp.com/channel/0029VakL5eBK5cDLzxxA411I"
global.themeemoji = '💫'
global.wm = "Asisten Elaina Kawai"
global.botscript = 'https://chat.whatsapp.com/LvmL37IubFNCPGU0cp62hA?mode=gi_t' //script link
global.packname = "ELAINA"
global.author = "\n\n\n\n\nDibuat Oleh Asisten Elaina\nYT | ShyoCode"
global.creator = "6282176642989@s.whatsapp.net"
//======================== CPANEL FITUR ===========================\\
global.domain = 'https://panel.sekedarstore.com' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = 'ptla_RiqNf0iCr6s08DLTwkXgWndOhZRJ4VxKRi4oJG4Wtu6' // Isi Apikey Plta Lu
global.capikey = 'ptlc_dHqgrA1oZZ0n6AA4hiT2uCKGKHpKxU5xjL1bxAJPKDx' // Isi Apikey Pltc Lu
//=========================================================//
global.apiDigitalOcean = "-"
//=========================================================//
//Server create panel egg pm2
global.apikey2 = '-' // Isi Apikey Plta Lu
global.capikey2 = '-' // Isi Apikey Pltc Lu
global.domain2 = '-' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah

global.eggsnya2 = '15' // id eggs yang dipakai
global.location2 = '1' // id location
//===========================//
global.virtuSimApiKey = 'k6R8Z1xGVBdgPvO5hNyuS'
global.domainotp = "https://claudeotp.com/api"
global.eggsnya = '15' // id eggs yang dipakai
global.nodes = '2'
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
//===========================//
global.mess = {
   wait: "*_Tunggu Sebentar.. Bot lagi berenang... 🏊_*",
   success: "Yay! Bot berhasil 🎉",
   on: "Yay! Nyala nih! 😝",
   off: "Ahh! Mati deh.. 😴",
   query: {
       text: "Teksnya mana? Aku kan gabisa baca pikiran kaka 😉",
       link: "Linknya dongg.. Aku gabisa tanpa link 😖",
   },
   error: {
       fitur: "Whoops! Eror nih.. laporkan ke owner agar diperbaiki 6282176642989 🙏",
   },
   only: {
       group: "Eh, Kak! Fitur ini bisanya buat grup nihh 🫂",
       private: "Eh, Kak! Fitur ini cuman bisa dipake chat pribadi! 🌚",
       owner: "Hanya untuk sang *Raja* 👑",
       admin: "Fitur ini cuman bisa dipake admin grup yah! 🥳",
       badmin: "Waduh! Aku butuh jadi admin agar bisa menggunakan fitur ini 🤯",
       premium: "Kak, ini fitur premium loh! Biar bisa jadi premium beli di 6285187063723 agar bisa menggunakan fitur ini 🤫",
   }
}
//========================================\\
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.sessionName = 'elaina'
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

global.keyopenai = "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"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'
global.supaurl = 'https://uzyzpgujphlmesbmcwca.supabase.co'
global.supakey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV6eXpwZ3VqcGhsbWVzYm1jd2NhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUwNjQwMjcsImV4cCI6MjA3MDY0MDAyN30.SwjgDAcEDLvjmzKzxHPdtHdjLbH1Zsr20MbPI4s6F94'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
